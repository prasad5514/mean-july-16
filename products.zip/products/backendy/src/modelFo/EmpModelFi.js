const mongoose=require("mongoose");
mongoose.connect('mongodb://localhost:27017/CrudDB',(err) => {
    if (!err)
        console.log('MongoDB connection succeeded.');
    else
        console.log('Error in DB connection : ' + JSON.stringify(err, undefined, 2));
});
const Schema=mongoose.Schema;     
    var NewProductSchema=new Schema({
        // name: { type: String },
        // position: { type: String },
        // office: { type: String },
        // salary: { type: Number }
        name:String,
        position:String,
        office:String,
        salary:Number
    });
    var Employeedata=mongoose.model("employee",NewProductSchema);
    module.exports=Employeedata;

