const express =require('express');
const ProductData=require('./src/model/Productdata');
const cors=require("cors");  //cross origin resource sharing 
var bodyparser=require('body-parser');
var app=new express;
app.use(cors());  //resource sharing will  occure,consolidating two port
app.use(bodyparser.json())

//var app=new express;//const app=new express();
var router=require("./src/routesFo/routerFi");
app.use('/',router);
//app.use(cors({ origin: 'http://localhost:4200' }));




    app.listen(3000,function(){
        console.log('listening to port 3000');
    })
