const express =require('express');
const ProductData=require('./src/model/Productdata');
const cors=require("cors");  //cross origin resource sharing 
var bodyparser=require('body-parser');
var app=new express();
app.use(cors());  //resource sharing will  occure,consolidating two port
app.use(bodyparser.json())

app.get('/products',function(req,res){
    res.header("access-Control-Allow-Origin","*")
    res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE')
    ProductData.find()
    .then(function(products){
        res.send(products);
    })
})
    app.post('/insert',function(req,res){
        res.header("Access-Control-Allow-Origin","*")
        res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE')
        console.log(req.body);
        var product={
            productId:req.body.product.productId,
            productName:req.body.product.productName,
            productCode:req.body.product.productCode,
            releaseDate:req.body.product.releaseDate,
            description:req.body.product.description,
            price:req.body.product.price,
            starRating:req.body.product.starRating,
            imageUrl:req.body.product.imageUrl
        }
        var product=new ProductData(product);
        product.save();
    });

    //app.get("/products/:id2",function(req,res){
    app.get("/products/iid2",function(req,res){    
        const id3=req.params.id2
        ProductData.findOne({_id:id3})
        // res.header("access-Control-Allow-Origin","*")
        // res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE')
        .then(function(product1){
            //res.render("prodet",{
                res.send("product1")
            //product1
           //});
        });
    });


    app.listen(3000,function(){
        console.log('listening to port 3000');
    })
