import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { NewProductComponent } from './new-product/new-product.component';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  //created object(http) of HttpClient
  constructor( private http:HttpClient ) { }
  getProducts(){
    return this.http.get("http://localhost:3000/products");
  }
  newProduct(item){
    return this.http.post("http://localhost:3000/insert",{"product":item})
    .subscribe(data=>{console.log(data)})
  }
  prodetser(){
    return this.http.get("http://localhost:3000/products/:id2");
  }
}

