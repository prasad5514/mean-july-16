import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProModel } from './product-list/product.model';
import { empModel } from './crudd/employee.model';
//import { NewProductComponent } from './new-product/new-product.component';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  readonly baseURL1 = 'http://localhost:3000/products';
  //created object(http) of HttpClient
  constructor( private http:HttpClient ) { }
  //products:ProModel[];
  getProducts(){
    return this.http.get("http://localhost:3000/products");
  }
  newProduct(item){  //item is product filled by the user 
    return this.http.post("http://localhost:3000/insert",{"product2":item})//attaching the item,we are naming it as product
    .subscribe(data=>{console.log(data)})
  }


  // postEmployee(pro2: ProModel) {  //adding
  //   return this.http.post(this.baseURL1, pro2);
  // }

  getProductList() {    //displayfull
    return this.http.get(this.baseURL1);
  }

  // putEmployee(pro4: ProModel) {  //edit
  //   return this.http.put(this.baseURL1 + `/${pro4._id}`, pro4);
  // }

  // deleteEmployee(_id: string) {   //delete
  //   return this.http.delete(this.baseURL1 + `/${_id}`);
  // }

  //readonly baseURL = 'http://localhost:3001/employees';
  postEmployee(emp2: empModel) {  //adding one
    return this.http.post(this.baseURL1, emp2);
  }

  getEmployeeList() {    //displayfull
    return this.http.get(this.baseURL1);
  }

  putEmployee(emp4: empModel) {  //edit
    return this.http.put(this.baseURL1 + `/${emp4._id}`, emp4);
  }

  deleteEmployee(_id: string) {   //delete
    return this.http.delete(this.baseURL1 + `/${_id}`);
  }
 
}

