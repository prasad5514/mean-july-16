import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ProductModel } from '../product-list/product.model';

@Component({
  selector: 'app-pro-det',
  templateUrl: './pro-det.component.html',
  styleUrls: ['./pro-det.component.css']
})
export class ProDetComponent implements OnInit {
  title:string="Product List";
  products:ProductModel[];
  imageWidth:number=50;
  imageMargin:number=2;

  showImage: boolean=false;
  toggleImage():void{
    this.showImage=!this.showImage
  }

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    //this.products._id
    this.productService.getProducts().subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data));
    })
  }

}
