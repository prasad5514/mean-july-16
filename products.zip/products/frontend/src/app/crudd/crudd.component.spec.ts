import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CruddComponent } from './crudd.component';

describe('CruddComponent', () => {
  let component: CruddComponent;
  let fixture: ComponentFixture<CruddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CruddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CruddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
