import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
//import { EmpSerService } from '../emp-ser.service';
import { ProductService } from '../product.service';  
import { empModel } from './employee.model';
import { ProModel } from '../product-list/product.model';

declare var M: any;

@Component({
  selector: 'app-crudd',
  templateUrl: './crudd.component.html',
  styleUrls: ['./crudd.component.css'],
  //providers: [EmpSerService]
  providers: [ProductService]
})

// //export class EmployeeComponent implements OnInit {
   export class CruddComponent implements OnInit {

  //constructor(public employeeService: EmpSerService) { }
  constructor(public productService: ProductService) { }
//   //selectedEm=new empModel(null,null,null,null,null);
//   //emp7=new empModel(null,null,null,null,null);
//   //selectedEmp=new empModel;
  emp6=new empModel;
  emp7:empModel[];
  // emp6=new ProModel;
  // emp7:ProModel[];

// ngOnInit(): void {
// }

  ngOnInit() {
    this.resetForm();
    this.refreshProductList();
  }

  resetForm(form?: NgForm) {
    if (form)
      form.reset();
        this.emp6={
      _id: "",
      productId: null,
      productName: "",
      productCode: "",
      releaseDate: "",
      description: "",
      price: null,
      starRating: null,
      imageUrl: ""
    }
  }

  onSubmit(form: NgForm) {
    if (form.value._id == "") {
      this.productService.postProduct(form.value).subscribe((res) => {
        //this.employeeService.newProduct(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshProductList();
        M.toast({ html: 'Saved successfully', classes: 'rounded' });
      });
    }
    else {
      this.productService.putProduct(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshProductList();
        M.toast({ html: 'Updated successfully', classes: 'rounded' });
      });
    }
  }

  refreshProductList() {
    this.productService.getProductList().subscribe((data) => {   //res=data
      //this.employeeService.employees = res as empModel[];
      this.emp7=JSON.parse(JSON.stringify(data));
    });
  }

  onEdit(emp8: empModel) {
    // this.employeeService.selectedEmployee = emp;
    this.emp6 = emp8;
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.productService.deleteProduct(_id).subscribe((res) => {
        this.refreshProductList();
        this.resetForm(form);
        M.toast({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }

  // onDelete(_id:string,form: NgForm){
  //   this.employeeService.deleteEmployee(_id).subscribe((res)=>{
  //     this.refreshEmployeeList();
  //   })
  // }
  // onDelete(_id:string){
  //   this.employeeService.deleteEmployee(_id).subscribe((res)=>{
  //     this.refreshEmployeeList();
  //   })
  // }

  // productItem=new ProModel(null,null,null,null,null,null,null,null);
  // AddProduct(){
  //   this.employeeService.newProduct(this.productItem);//we are passing productItem to newProduct function
  //   console.log("Called");
  //   alert("Success");
  //   //this.router.navigate(['/']);
  // }

 }

