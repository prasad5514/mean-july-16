import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { NewProductComponent } from './new-product/new-product.component';
//import { ProDetComponent } from './pro-det/pro-det.component'
import { CrudComponent } from './crud/crud.component';
import { CruddComponent } from './crudd/crudd.component';

const routes: Routes = [
  {path:'',component:ProductListComponent},
{path:'add',component:NewProductComponent},
// {path:'crud',component:CrudComponent},
{path:'crudd',component:CruddComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
