import { Component, OnInit } from '@angular/core';
import { ProModel } from './product.model';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  title:string="Product List";
  //data from the backend will store in variable products by following the format ProductModel(like a schema)
  product6:ProModel[];
  //image properties
  imageWidth:number=50;
  imageMargin:number=2;

  showImage: boolean=false;
  toggleImage():void{
    this.showImage=!this.showImage
  }

  //productservice is a object of class ProductService
  constructor(private productService: ProductService,private router: Router){
  }

  ngOnInit(): void {
    //product details from db will store in "data"
    this.productService.getProducts().subscribe((data)=>{
      this.product6=JSON.parse(JSON.stringify(data));
    })
  }
  
}
