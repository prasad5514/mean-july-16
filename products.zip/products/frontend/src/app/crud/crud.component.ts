import { Component, OnInit } from '@angular/core';

import { ProductService } from '../product.service';
import { ProModel } from './product.model';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

declare var M: any;

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css'],
  providers: [ProductService]
})
// export class CrudComponent implements OnInit {
//   title:String="Add Product";


//   productItem=new ProductModel(null,null,null,null,null,null,null,null);

//   ngOnInit(): void {
//   }
//   AddProduct(){
//     this.productService.newProduct(this.productItem);//we are passing productItem to newProduct function
//     console.log("Called");
//     alert("Success");
//     this.router.navigate(['/']);
//   }

// }



// import { EmployeeService } from '../shared/employee.service';

// import { Employee } from '../shared/employee.model';
//import { empModel } from './employee.model';

//declare var M: any;

// @Component({
//   selector: 'app-employee',
//   templateUrl: './employee.component.html',
//   styleUrls: ['./employee.component.css'],
//   providers: [ProductService]
// })

export class CrudComponent implements OnInit {

  constructor(private productService: ProductService,private router: Router) { }
  // selectedEm=new Employee(null,null,null,null,null);
  // selectedPro=new ProductModel;
  //product6=new ProModel;
  //product6=new ProModel(null,null,null,null,null,null,null,null);
  product7:ProModel[];
  

  ngOnInit() {
    //this.resetForm();
    this.refreshProductList();
     //product details from db will store in "data"
    //  this.productService.getProducts().subscribe((data)=>{
    //   this.product7=JSON.parse(JSON.stringify(data));
    //})

  }

  // resetForm(form?: NgForm) {
  //   if (form)
  //     form.reset();
  //   // this.employeeService.selectedEmployee = {
  //     // this.selectedEmp = {
  //       this.product6={

  //     _id: "",
  //     productId: null,
  //     productName: "",
  //     productCode: "",
  //     releaseDate: "",
  //     description: "",
  //     price: null,
  //     starRating: null,
  //     imageUrl: ""
  //   }
  // }


  // onSubmit(form: NgForm) {
  //   if (form.value._id == "") {
  //     this.productService.postEmployee(form.value).subscribe((res) => {
  //       //this.resetForm(form);
  //       this.refreshProductList();
  //       M.toast({ html: 'Saved successfully', classes: 'rounded' });
  //     });
  //   }
  //   else {
  //     this.productService.putEmployee(form.value).subscribe((res) => {
  //       //this.resetForm(form);
  //       this.refreshProductList();
  //       M.toast({ html: 'Updated successfully', classes: 'rounded' });
  //     });
  //   }
  // }

  refreshProductList() {
    this.productService.getProductList().subscribe((data) => {   //res=data
      //this.employeeService.employees = res as empModel[];
      this.product7=JSON.parse(JSON.stringify(data));
    });
  }

  // onEdit(emp: ProModel) {
  //   // this.employeeService.selectedEmployee = emp;
  //   this.product6 = emp;
  // }

  // onDelete(_id: string, form: NgForm) {
  //   if (confirm('Are you sure to delete this record ?') == true) {
  //     this.employeeService.deleteEmployee(_id).subscribe((res) => {
  //       this.refreshEmployeeList();
  //       this.resetForm(form);
  //       M.toast({ html: 'Deleted successfully', classes: 'rounded' });
  //     });
  //   }
  // }

  // onDelete(_id:string,form: NgForm){
  //   this.employeeService.deleteEmployee(_id).subscribe((res)=>{
  //     this.refreshEmployeeList();
  //   })
  // }
  onDelete(_id:string){
    this.productService.deleteEmployee(_id).subscribe((res)=>{
      this.refreshProductList();
    })
  }

}

