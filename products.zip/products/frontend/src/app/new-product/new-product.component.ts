import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ProductModel } from '../product-list/product.model';
//import { Routes, RouterModule } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {
  title:String="Add Product";
  //creating the object(productService) of ProductService,,creating the object(router) of  class Router for navigation or redirecting to another page 
  constructor(private productService: ProductService,private router: Router) { }
  productItem=new ProductModel(null,null,null,null,null,null,null,null);
  //productItem need to send to backend or data base,creating new object of ProductModel 

  ngOnInit(): void {
  }
  AddProduct(){
    this.productService.newProduct(this.productItem);//we are passing productItem to newProduct function
    console.log("Called");
    alert("Success");
    this.router.navigate(['/']);
  }

}
